import os
import sys
import argparse
import numpy as np
import scipy
from scipy import io, misc, sparse
from sklearn.preprocessing import normalize

PIC_DIR = 'pics'
EXTENSION = '.bmp'

def cartesian(arrays, out=None):

    arrays = [np.asarray(x) for x in arrays]
    dtype = arrays[0].dtype
    n = np.prod([x.size for x in arrays])
    if out is None:
        out = np.zeros([n, len(arrays)], dtype=dtype)
    m = n / arrays[0].size
    out[:,0] = np.repeat(arrays[0], m)
    if arrays[1:]:
        cartesian(arrays[1:], out=out[0:m,1:])
        for j in range(1, arrays[0].size):
            out[j*m:(j+1)*m,1:] = out[0:m,1:]
    return out

# DEFINE THE FUNCTION TO CONVERT RGB TO YUV
def RGB2YUV(RGB):
    R = RGB[:,:,0]/255.0
    G = RGB[:,:,1]/255.0
    B = RGB[:,:,2]/255.0
    Y = 0.299*R + 0.587*G + 0.114*B
    U = 0.60*R - 0.28*G - 0.32*B
    V = 0.21*R - 0.52*G + 0.31*B
    YUV = np.zeros(RGB.shape)
    YUV[:,:,0] = Y
    YUV[:,:,1] = U
    YUV[:,:,2] = V
    return YUV

# DEFINE THE FUNCTION TO CONVERT YUV TO RGB   
def YUV2RGB(YUV):
    Y = YUV[:,:,0]
    U = YUV[:,:,1]
    V = YUV[:,:,2]
    R = Y + 0.948262*U + 0.624013*V
    G = Y - 0.276066*U - 0.639810*V
    B = Y - 1.105450*U + 1.729860*V
    R[R < 0] = 0
    R[R > 1] = 1
    G[G < 0] = 0
    G[G > 1] = 1
    B[B < 0] = 0
    B[B > 1] = 1
    RGB = np.zeros(YUV.shape)
    RGB[:,:,0] = R*255.0
    RGB[:,:,1] = G*255.0
    RGB[:,:,2] = B*255.0
    
    return np.uint8(RGB)
   
# TO FIND THE LOCATION OF MARK AREA
def find_marked_space(image, marked):
    diff = marked - image
    diff_loc = abs(diff).sum(2) > 0.01
    return diff_loc

def find_neighbor(position_matrix, r):
    d = 1
    l1, h1 = max(r[0]-d, 0), min(r[0]+d, position_matrix.shape[0])
    l2, h2 = max(r[1]-d, 0), min(r[1]+d, position_matrix.shape[1])
    return position_matrix[l1:h1 + 1, l2:h2 + 1]

def generate_std2_matrix(Y):
    res = np.zeros(Y.shape, dtype='float32')
    for i in range(Y.shape[0]):
        for j in range(Y.shape[1]):
            res[i, j] = np.square(np.std(find_neighbor(Y, [i, j])))
    return res

def calc_weight(r, S, Y, std2):
    result = []
    for s in S:
        result.append(-1 * np.exp(-1 * np.square(Y[r] - Y[s]) / 2 * std2[r]))
    return result

def generate_weight_matrix(Y):
    (height, width) = Y.shape[0:2]
    cart = cartesian([range(height), range(width)])
    cart_r = cart.reshape(height, width, 2) # cart_r[i, j] is [i, j]
    size = height * width
    xy2idx = np.arange(size).reshape(height, width) # linear rank of [i, j]
    W = sparse.lil_matrix((size, size)) # sparse matrix map (h, w) -> (h, w)
    std2_matrix = generate_std2_matrix(Y) # std2 matrix (h, w)
    for i in range(height):
        for j in range(width):
            current_index = xy2idx[i, j]
            neighbors = find_neighbor(cart_r, [i, j]).reshape(-1, 2)
            neighbors = [tuple(item) for item in neighbors] # list of [i, j] of current point
            neighbors.remove((i, j))
            neighbor_indexes = [xy2idx[pos] for pos in neighbors]
            current_weights = calc_weight((i, j), neighbors, Y, std2_matrix)
            W[current_index, neighbor_indexes] = np.asmatrix(current_weights)
    Wn = normalize(W, norm = 'l1', axis = 1)
    Wn[np.arange(size), np.arange(size)] = 1
    return Wn, xy2idx
    
def main(arguments):
    # ---------------- Data Preparation ------------------
#    parser = argparse.ArgumentParser(
#        description=__doc__,
#        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
#    parser.add_argument('--input', help='Specify the name of the black and white picture.', type=str, default='example')
#    parser.add_argument('--marked', help='Specify the name of the marked picture', type=str, default='example_marked')
#    parser.add_argument('--output', help='Specify the output name you want.', type=str, default='cahl_output')

#    args = parser.parse_args(arguments)
#    bw_name = args.input
#    marked_name = args.marked
#    out_name = args.output



#    bw_file_path = os.path.join(PIC_DIR, bw_name + EXTENSION)
#    marked_file_path = os.path.join(PIC_DIR, marked_name + EXTENSION)
#    out_file_path = os.path.join(PIC_DIR, out_name + EXTENSION)

    bw_file_path = 'example.bmp'
    marked_file_path = 'example_marked.bmp'
    out_file_path = 'test.bmp'
    
    blackwhite_RGB = misc.imread(bw_file_path)
    marked_RGB = misc.imread(marked_file_path)
    
    # CONVERT FROM RGB FORMAT TO YUV FORMAT    
    blackwhite_YUV = RGB2YUV(blackwhite_RGB)
    Y              = blackwhite_YUV[:,:,0]
    marked_YUV     = RGB2YUV(marked_RGB)
  
    row, col       = Y.shape[0:2]
    size           = row * col
    
    
    # ---------------- Find marked space ------------------
    colored = find_marked_space(blackwhite_RGB, marked_RGB)
    # ---------------- Generate weight matrix ------------------
    Wrs, xy2idx = generate_weight_matrix(Y)
    Wrs = Wrs.tolil()
    for idx in [xy2idx[pos] for pos in colored]:
        Wrs[idx] = sparse.csr_matrix(([1.0], ([0], [idx])), shape=(1, size))

    # ---------------- Optimization ------------------
    LU = scipy.sparse.linalg.splu(Wrs.tocsc())
    
    b1 = marked_YUV[:, :, 1].flatten()
    b2 = marked_YUV[:, :, 2].flatten()

    x1 = LU.solve(b1)
    x2 = LU.solve(b2)

    sol = np.zeros(blackwhite_RGB.shape)
    sol[:, :, 0] = Y
    sol[:, :, 1] = x1.reshape((row, col))
    sol[:, :, 2] = x2.reshape((row, col))
#    sol_rgb = yuv2rgb(sol)
    sol_RGB = np.uint8(YUV2RGB(sol))
    
    misc.imsave(out_file_path, sol_RGB)
    print('Colorized picture saved to', out_file_path)

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
    
    
'''

    bw_file_path = 'example.bmp'
    marked_file_path = 'example_marked.bmp'
    out_file_path = 'TEST.bmp'
    
    bw_rgb = misc.imread(bw_file_path)
    marked_rgb = misc.imread(marked_file_path)
    
    bw = RGB2YUV(bw_rgb)
    Y = np.array(bw[:, :, 0], dtype='float64')
    marked = RGB2YUV(marked_rgb)
    (height, width) = Y.shape[0:2]
    size = height * width
    # ---------------- Find marked space ------------------
    colored = find_marked_space(bw_rgb, marked_rgb)
    # ---------------- Generate weight matrix ------------------
    Wrs, xy2idx = generate_weight_matrix(Y)
    Wrs = Wrs.tolil()
    for idx in [xy2idx[pos] for pos in colored]:
        Wrs[idx] = sparse.csr_matrix(([1.0], ([0], [idx])), shape=(1, size))

    # ---------------- Optimization ------------------
    LU = scipy.sparse.linalg.splu(Wrs.tocsc())
    
    b1 = marked[:, :, 1].flatten()
    b2 = marked[:, :, 2].flatten()

    x1 = LU.solve(b1)
    x2 = LU.solve(b2)

    sol = np.zeros(bw.shape)
    sol[:, :, 0] = Y
    sol[:, :, 1] = x1.reshape((height, width))
    sol[:, :, 2] = x2.reshape((height, width))
#    sol_rgb = yuv2rgb(sol)
    sol_rgb = np.uint8(yuv2rgb(sol))
    
    misc.imsave(out_file_path, sol_rgb)
    print('Colorized picture saved to', out_file_path)