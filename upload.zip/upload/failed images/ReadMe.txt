Fail 1:forgot to add the center as weight 1
Fail 2: forgot to times 255 when convert YUV to RGB
Fail 3 (same as 2): 320 cols vs 265 rows (should put first)
Fail 4: YUV to RGB, all to R, no G or B
Fail 5: forgot to update row index

A[1].nonzero()
Out[310]: (array([0, 0, 0, 0, 0, 0]), array([  0,   1,   2, 265, 266, 267]))

A[1,0]
Out[311]: -0.014043405122479357

A[1,2]
Out[312]: -0.47893489231627673

A[1,265]
Out[313]: -0.014043405122479357

A[1,266]
Out[314]: -0.47893489231627673

A[1,267]
Out[315]: -0.014043405122487775




A[1].nonzero()
Out[319]: (array([0, 0, 0, 0, 0, 0]), array([  0,   1,   2, 265, 266, 267]))

A[1,0]
Out[320]: -0.014043405122479357

A[1,2]
Out[321]: -0.47893489231627673

A[1,265]
Out[322]: -0.014043405122479357

A[1,266]
Out[323]: -0.47893489231627673

A[1,267]
Out[324]: -0.014043405122487775