import numpy as np
import matplotlib.pyplot as plt
from scipy import misc
from scipy import io
from scipy import sparse
from scipy.sparse import linalg
import colorsys
import os
import time
import sys



os.system('cls')
os.system('reset')

def YUV2RGB(Y, U, V):                                                        # the code from colorsys.yiq_to_rgb is modified to work for arrays
    R = Y + 0.948262*U + 0.624013*V
    G = Y - 0.276066*U - 0.639810*V
    B = Y - 1.105450*U + 1.729860*V
    R[R < 0] = 0
    R[R > 1] = 1
    G[G < 0] = 0
    G[G > 1] = 1
    B[B < 0] = 0
    B[B > 1] = 1
    return (R, G, B)


def RGB2YUV(R, G, B):
    Y = 0.30*R + 0.59*G + 0.11*B
    U = 0.60*R - 0.28*G - 0.32*B
    V = 0.21*R - 0.52*G + 0.31*B
    return (Y, U, V)

def weighting(Y,i,j,wd,mode):

    row,col = Y.shape[0:2]
    center  = Y[i,j]
    idx = 0
    num_pix = (1+2*wd)**2
    vals    = np.zeros([num_pix,1])
    weights = np.zeros([num_pix,1])
    loc_row = np.zeros([num_pix,1])
    loc_col = np.zeros([num_pix,1])

    for ii in range(max(0, i-wd), min(i+wd+1,row)):
        for jj in range(max(0, j-wd), min(j+wd+1, col)):
            if ii != i and jj != j:
                vals[idx]    = Y[ii,jj]
                loc_row[idx] = ii 
                loc_col[idx] = jj 
                idx          = idx + 1
    vals[idx]   = center
    variance    = np.mean((vals[0:idx+1] - np.mean(vals[0:idx+1]))**2)
    variance    = 0.6 * variance

    mgv = min((vals[0:idx+1] - center)**2)
    if (variance < (-mgv / np.log(0.01))):
    	variance = - mgv / np.log(0.01)
    if (variance < 0.000002):
    	variance = 0.000002
	
    if mode == 1:
        weights[0:idx] = np.exp( -((vals[0:idx] - center)**2) / variance )
        weights[0:idx] = vals[0:idx] / np.sum(vals[0:idx])
    elif mode == 2:
        mu = np.mean(vals[0:idx])
        weights[0:idx] = np.ones([idx,1]) + (center - mu)*(vals[0:idx] - mu*np.ones([idx,1]))/variance
        weights[0:idx] = vals[0:idx] / np.sum(vals[0:idx])

    return loc_row[0:idx],loc_col[0:idx],weights[0:idx]









# ---------------------------------------------------------------------------- #
# ------------------------------- PREPARE ------------------------------------ #
# ---------------------------------------------------------------------------- #

#o_img = input('Enter original file name (using single quotes): ')
#m_img = input('Enter marked file name (using single quotes): ')

#dir_path = os.path.dirname(os.path.realpath(__file__))
#original = misc.imread(os.path.join(dir_path, o_img))
#marked = misc.imread(os.path.join(dir_path, m_img))

original   = misc.imread('example.bmp')
marked     = misc.imread('example_marked.bmp')

original   = original.astype(float)/255
marked     = marked.astype(float)/255

isColored  = abs(original - marked).sum(2) > 0.01                                # isColored as colorIm 

#(Y,_,_)    = colorsys.rgb_to_yiq(original[:,:,0],original[:,:,1],original[:,:,2])
#(_,I,Q)    = colorsys.rgb_to_yiq(marked[:,:,0],marked[:,:,1],marked[:,:,2])
(Y,_,_)    = RGB2YUV(original[:,:,0],original[:,:,1],original[:,:,2])
(_,U,V)    = RGB2YUV(marked[:,:,0],marked[:,:,1],marked[:,:,2])

YUV        = np.zeros(original.shape)                                                  # YUV as ntscIm
YUV[:,:,0] = Y
YUV[:,:,1] = U
YUV[:,:,2] = V

'''
max_d = np.floor(np.log(min(YUV.shape[0],YUV.shape[1]))/np.log(2)-2)
iu = np.floor(YUV.shape[0]/(2**(max_d - 1))) * (2**(max_d - 1))
ju = np.floor(YUV.shape[1]/(2**(max_d - 1))) * (2**(max_d - 1))
isColored = isColored[:iu,:ju].copy()
YUV = YUV[:iu,:ju].copy()
'''
                                                                                # ALTERNATIVE :: colorized = abs(getColorExact( colorIm, YUV ));

# ---------------------------------------------------------------------------- #
# ---------------------------- getExactColor --------------------------------- #
# ---------------------------------------------------------------------------- #

                                                                                # YUV as ntscIm
num_row = Y.shape[0]                                                                # n = image height
num_col = Y.shape[1]                                                                # m = image width
N       = num_row*num_col

loc_matrix = np.arange(N).reshape(num_row,num_col,order='F').copy()            # indices_matrix as indsM

wd = 1 
weight_mode = 1                                                                         # The radius of window around the pixel to assess
num_pixel_window = (2*wd + 1)**2                                                  # The number of pixels in the window around one pixel
max_nr = N * num_pixel_window                                            # Maximal size of pixels to assess for the hole image
                                                                                # (for now include the full window also for the border pixels)
row_inds = np.zeros(max_nr, dtype=np.int64)
col_inds = np.zeros(max_nr, dtype=np.int64)
vals     = np.zeros(max_nr)

# ----------------------------- Interation ----------------------------------- #
length = 0 
idx_row = 0
A = sparse.csr_matrix((N, N))
# iterate over pixels in the image
for j in range(num_col):
    for i in range(num_row):
        
        # If current pixel is not colored
        idx_row = i*num_col + j
        if (not isColored[i,j]):
            length = len(loc_row)
            loc_row,loc_col,weights = weighting(Y,i,j,wd,weight_mode)
            
            col_N[] = loc_col*num_row + loc_col
#           A[row_N,col_N] = - weights
            
        # END IF NOT COLORED
        
        # Add the values for the current pixel
        col_N          = row_N
        A[row_N,col_N] = 1



# ---------------------------------------------------------------------------- #
# ------------------------ After Iteration Process --------------------------- #
# ---------------------------------------------------------------------------- #

# Trim to variables to the length that does not include overflow from the edges

# io.mmwrite(os.path.join(dir_path, 'sparse_matrix'), A)
b = np.zeros((A.shape[0]))


colorized = np.zeros(YUV.shape)                                                 # colorized as nI = resultant colored image
colorized[:,:,0] = Y

# colored portion
color_copy_for_nonzero = isColored.reshape(N,order='F').copy()                   # We have to reshape and make a copy of the view of an array for the nonzero() to work like in MATLAB

# find there non zero, that is colored
colored_inds = np.nonzero(color_copy_for_nonzero)                               # colored_inds as lblInds

for t in [1,2]:
    curIm = YUV[:,:,t].reshape(N,order='F').copy()
    b[colored_inds] = curIm[colored_inds]
    new_vals = linalg.spsolve(A, b)                                             # new_vals = linalg.lsqr(A, b)[0] # least-squares solution (much slower), slightly different solutions
    # lsqr returns unexpectedly (ndarray,ndarray) tuple, first is correct so:
    # use new_vals[0] for reshape if you use lsqr
    colorized[:,:,t] = new_vals.reshape(num_row, num_col, order='F')


    
# ---------------------------------------------------------------------------- #
# ------------------------------ Back to RGB --------------------------------- #
# ---------------------------------------------------------------------------- #

(R, G, B) = YUV2RGB(colorized[:,:,0],colorized[:,:,1],colorized[:,:,2])
colorizedRGB = np.zeros(colorized.shape)
colorizedRGB[:,:,0] = R                                                         # colorizedRGB as colorizedIm
colorizedRGB[:,:,1] = G
colorizedRGB[:,:,2] = B

plt.imshow(colorizedRGB)
plt.show()

#misc.imsave(os.path.join(dir_path, 'example3_colorized.bmp'), colorizedRGB, format='bmp')
