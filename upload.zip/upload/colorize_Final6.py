import numpy as np
import matplotlib.pyplot as plt
from scipy import misc
from scipy import io
from scipy import sparse
from scipy.sparse import linalg
import colorsys
import os
import time
import sys
import argparse

os.system('cls')
os.system('reset')

PIC_DIR = 'pics'
EXTENSION = '.bmp'

def YUV_to_RGB(Y, U, V):                                                        # the code from colorsys.yiq_to_rgb is modified to work for arrays
    R = Y + 0.948262*U + 0.624013*V
    G = Y - 0.276066*U - 0.639810*V
    B = Y - 1.105450*U + 1.729860*V
    R[R < 0] = 0
    R[R > 1] = 1
    G[G < 0] = 0
    G[G > 1] = 1
    B[B < 0] = 0
    B[B > 1] = 1
    return (R, G, B)


def RGB_to_YUV(R, G, B):
    Y = (0.30*R + 0.59*G + 0.11*B)/255.0
    U = (0.60*R - 0.28*G - 0.32*B)/255.0
    V = (0.21*R - 0.52*G + 0.31*B)/255.0
    return (Y, U, V)

def find_marked(blackwhite, marked):
    blackwhite = blackwhite.astype(float) / 255.0
    marked     = marked.astype(float) / 255.0
    
    return abs(blackwhite - marked).sum(2) > 0.01

def index_matrix(YUV):
    n = YUV.shape[0]
    m = YUV.shape[1]
    image_size = n*m
    return np.arange(image_size).reshape(n,m,order='F').copy()
        
def find_neighbor(Y,r,wd):
    max_num = (1+2*wd)**2
    idx_col=np.zeros(max_num,dtype=np.int64)
    window_vals = np.zeros(max_num,dtype=np.float64)
    idx = 0
    for ii in range(max(0,r[0]-wd),min(r[0]+wd+1,Y.shape[0])):
        for jj in range(max(0,r[1]-wd),min(r[1]+wd+1,Y.shape[1])):
            if (ii != r[0] or jj != r[1]):
                location_matrix   = index_matrix(Y)
                idx_col[idx]      = location_matrix[ii,jj]
#                idx_col[idx]      =index_matrix(Y)[ii,jj]
                window_vals[idx]  = Y[ii,jj]
                idx               = idx +1
    return idx,idx_col[0:idx],window_vals[0:idx]    
            
def calc_variance(Y,window_vals,r):
#    _,_,temp_vals = find_neighbor(Y,r,wd)
#    length = length + temp_num
    #window_index = window_index + temp_num
#    col_inds[length - temp_num:length] = temp_col_inds
#    row_inds[length - temp_num:length] = pixel_nr
#    window_vals[0:temp_num] = temp_vals
     
    center = Y[r[0],r[1]].copy()                                          # t_val as center
#    window_vals[temp_num] = center
    variance = np.mean((window_vals - np.mean(window_vals))**2) # variance as c_var
    sigma = variance * 0.6                                              #csig as sigma
    
    # Indeed, magic
    mgv = min(( window_vals - center )**2)            
    if (sigma < ( -mgv / np.log(0.01 ))):
        sigma = -mgv / np.log(0.01)                                     
    if (sigma < 0.000002):                                        
        sigma = 0.000002
    
    return sigma        
                                                                  
def calc_weights(Y,window_vals,sigma,r):
    center  = Y[r[0],r[1]]
    weights = np.exp( -((window_vals - center)**2) / sigma )  
    weights = weights / np.sum(weights)
    return weights



# ---------------------------------------------------------------------------- #
# ------------------------------- PREPARE ------------------------------------ #
# ---------------------------------------------------------------------------- #
def main():
    
     # ---------------- DATA PREPARATION ------------------
    parser = argparse.ArgumentParser(description="Intelligently color black and white images")
    parser.add_argument('-i','--input',help='Specify the name of black and white image')
    parser.add_argument('-m','--mark',help='Specify the name of marked image')
    parser.add_argument('-o','--output',help='Specify the output file name')
    
    args = vars(parser.parse_args())
    print(args)
    
    blackwhite_path = args['input']
    mark_path     = args['mark']
    out_name_path = args['output']

#    blackwhite_path = 'example'
#    mark_path     = 'example_marked'
#    out_name_path = 'test'
 
#    blackwhite_path='example'
    bw_file_path = os.path.join(PIC_DIR, blackwhite_path + EXTENSION)
    marked_file_path = os.path.join(PIC_DIR, mark_path + EXTENSION)
    out_file_path = os.path.join(PIC_DIR, out_name_path + EXTENSION)
    
    
#    dir_path = os.path.dirname(os.path.realpath(__file__))
    blackwhite_RGB = misc.imread(bw_file_path)
    marked_RGB     = misc.imread(marked_file_path)
    
#    blackwhite_RGB = misc.imread('example.bmp')
#    marked_RGB     = misc.imread('example_marked.bmp')
    
    
    isColored  = find_marked(blackwhite_RGB,marked_RGB)                                # isColored as colorIm 
    
    (Y,_,_)    = RGB_to_YUV(blackwhite_RGB[:,:,0],blackwhite_RGB[:,:,1],blackwhite_RGB[:,:,2])
    (_,U,V)    = RGB_to_YUV(marked_RGB[:,:,0],marked_RGB[:,:,1],marked_RGB[:,:,2])
    
    YUV        = np.zeros(blackwhite_RGB.shape)                                                  # YUV as ntscIm
    YUV[:,:,0] = Y
    YUV[:,:,1] = U
    YUV[:,:,2] = V
    
    
    
        
    # ---------------------------------------------------------------------------- #
    # ---------------------------- getExactColor --------------------------------- #
    # ---------------------------------------------------------------------------- #
                                                                                        # YUV as ntscIm
    n = YUV.shape[0]                                                                # n = image height
    m = YUV.shape[1]                                                                # m = image width
    image_size = n*m
    
    location_matrix = index_matrix(YUV)
    
    wd = 1                                                                          # The radius of window around the pixel to assess
    num_pixel = (2*wd + 1)**2                                                  # The number of pixels in the window around one pixel
    max_num    = image_size * num_pixel                                            # Maximal size of pixels to assess for the hole image
                                                                                    # (for now include the full window also for the border pixels)
    row_inds = np.zeros(max_num, dtype=np.int64)
    col_inds = np.zeros(max_num, dtype=np.int64)
    vals     = np.zeros(max_num)
    
    # ----------------------------- Interation ----------------------------------- #
    
    length = 0                                                                      # length as len
    pixel_nr = 0                                                                    # pixel_nr as consts_len
                                                                                    # Nr of the current pixel == row index in sparse matrix
    
    # iterate over pixels in the image
    for j in range(m):
        for i in range(n):
            
            # If current pixel is not colored
            if (not isColored[i,j]):
                #window_index = 0                                                    # window_index as tlen
                window_vals  = np.zeros(num_pixel)                             # window_vals as gvals 
                
                # Then iterate over pixels in the window around [i,j]
    #            for ii in range(max(0, i-wd), min(i+wd+1,n)):
    #                for jj in range(max(0, j-wd), min(j+wd+1, m)):
    #                    
    #                    # Only if current pixel is not [i,j]
    #                    if (ii != i or jj != j):
    #                        row_inds[length]          = pixel_nr
    #                        col_inds[length]          = location_matrix[ii,jj]
    #                        window_vals[window_index] = YUV[ii,jj,0]
    #                        length       += 1
    #                        window_index += 1
       
                temp_num,temp_col_inds,temp_vals = find_neighbor(YUV[:,:,0],[i,j],wd)
                length = length + temp_num
                #window_index = window_index + temp_num
                col_inds[length - temp_num:length] = temp_col_inds
                row_inds[length - temp_num:length] = pixel_nr
                window_vals[0:temp_num] = temp_vals
                
                sigma=calc_variance(YUV[:,:,0],temp_vals,[i,j])
                
#                center = YUV[i,j,0].copy()                                          # t_val as center
    #            window_vals[temp_num] = center
                                                                                    # calculate variance of the intensities in a window around pixel [i,j]
    #            variance = np.mean((window_vals[0:temp_num+1] - np.mean(window_vals[0:temp_num+1]))**2) # variance as c_var
    #            sigma = variance * 0.6                                              #csig as sigma
                
                # Indeed, magic
    #            mgv = min(( window_vals[0:temp_num+1] - center )**2)            
    #            if (sigma < ( -mgv / np.log(0.01 ))):
    #                sigma = -mgv / np.log(0.01)                                     
    #            if (sigma < 0.000002):                                              # avoid dividing by 0
    #                sigma = 0.000002
    #            weights = calc_weights(Y,temp_vals,sigma,[i,j])
    #            window_vals[0:temp_num] = np.exp( -((window_vals[0:temp_num] - center)**2) / sigma )    # use weighting funtion (2)
    #            window_vals[0:temp_num] = window_vals[0:temp_num] / np.sum(window_vals[0:temp_num]) # make the weighting function sum up to 1
    #            vals[length-temp_num:length] = -window_vals[0:temp_num]
    #            weights = 
                vals[length-temp_num:length] = - calc_weights(Y,temp_vals,sigma,[i,j])
                
            
            # END IF NOT COLORED
            
            # Add the values for the current pixel
            row_inds[length] = pixel_nr
            
            col_inds[length] = location_matrix[i,j]
            vals[length] = 1
            length += 1
            pixel_nr += 1
            
        # END OF FOR i
    # END OF FOR j
    
    
    
    # ---------------------------------------------------------------------------- #
    # ------------------------ After Iteration Process --------------------------- #
    # ---------------------------------------------------------------------------- #
    
    # Trim to variables to the length that does not include overflow from the edges
    vals = vals[0:length]
    col_inds = col_inds[0:length]
    row_inds = row_inds[0:length]
    
    # ------------------------------- Sparseness --------------------------------- #
    # sys.exit('LETS NOT SPARSE IT YET')
    A = sparse.csr_matrix((vals, (row_inds, col_inds)), (pixel_nr, image_size))
    
    # io.mmwrite(os.path.join(dir_path, 'sparse_matrix'), A)
    b = np.zeros((A.shape[0]))
    
    colorized = np.zeros(YUV.shape)                                                 # colorized as nI = resultant colored image
    colorized[:,:,0] = YUV[:,:,0]
    
    color_copy_for_nonzero = isColored.reshape(image_size,order='F').copy()                   # We have to reshape and make a copy of the view of an array for the nonzero() to work like in MATLAB
    colored_inds = np.nonzero(color_copy_for_nonzero)                               # colored_inds as lblInds
    
    for t in [1,2]:
        curIm = YUV[:,:,t].reshape(image_size,order='F').copy()
        b[colored_inds] = curIm[colored_inds]
        new_vals = linalg.spsolve(A, b)                                             # new_vals = linalg.lsqr(A, b)[0] # least-squares solution (much slower), slightly different solutions
        # lsqr returns unexpectedly (ndarray,ndarray) tuple, first is correct so:
        # use new_vals[0] for reshape if you use lsqr
        colorized[:,:,t] = new_vals.reshape(n, m, order='F')
        
    # ---------------------------------------------------------------------------- #
    # ------------------------------ Back to RGB --------------------------------- #
    # ---------------------------------------------------------------------------- #
    
    (R, G, B) = YUV_to_RGB(colorized[:,:,0],colorized[:,:,1],colorized[:,:,2])
    colorizedRGB = np.zeros(colorized.shape)
    colorizedRGB[:,:,0] = R                                                         # colorizedRGB as colorizedIm
    colorizedRGB[:,:,1] = G
    colorizedRGB[:,:,2] = B
    
    plt.imshow(colorizedRGB)
    plt.show()
    
#    misc.imsave(os.path.join(dir_path, 'test_colorized.bmp'), colorizedRGB, format='bmp')
    misc.imsave(out_file_path, colorizedRGB, format='bmp')


if __name__ == '__main__':
    main()