function RGB = ntsc2rgb(YUV)

    row     = size(YUV,1);
    col     = size(YUV,2);
    channel = size(YUV,3);

% YUV format
%     for ii = 1:row
%         for jj = 1:col
%             Y = YUV(ii,jj,1);
%             U = YUV(ii,jj,2);
%             V = YUV(ii,jj,3);
%             RGB(ii,jj,1) = 0.299 * Y + 0.587*U + 0.114 *V;
%             RGB(ii,jj,2) = 0.596 * Y - 0.274*U - 0.322 *V;
%             RGB(ii,jj,3) = 0.211 * Y - 0.523*U + 0.312 *V;
% 
%         end
%     end

% YIQ format
    for ii = 1:row
        for jj = 1:col
            Y = YUV(ii,jj,1);
            U = YUV(ii,jj,2);
            V = YUV(ii,jj,3);
            R = Y + 0.948262*U + 0.624013*V
            G = Y - 0.276066*U - 0.639810*V
            B = Y - 1.105450*U + 1.729860*V
            if R < 0.0
                R = 0.0;
            if G < 0.0
                G = 0.0;
            if B < 0.0
                B = 0.0;
            if R > 1.0
                R = 1.0;
            if G > 1.0
                G = 1.0;
            if B > 1.0
                B = 1.0;
        end
    end
end