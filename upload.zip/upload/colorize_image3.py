import numpy as np
import matplotlib.pyplot as plt
from scipy import misc
from scipy import sparse
from scipy.sparse import linalg
import os
import argparse

os.system('cls')
os.system('reset')

PIC_DIR = 'pics'
EXTENSION = '.bmp'

def YUV_to_RGB(YUV): 
    R = YUV[:,:,0] + 0.948262*YUV[:,:,1] + 0.624013*YUV[:,:,2]
    G = YUV[:,:,0] - 0.276066*YUV[:,:,1] - 0.639810*YUV[:,:,2]
    B = YUV[:,:,0] - 1.105450*YUV[:,:,1] + 1.729860*YUV[:,:,2]
    R[R < 0] = 0
    R[R > 1] = 1
    G[G < 0] = 0
    G[G > 1] = 1
    B[B < 0] = 0
    B[B > 1] = 1

    RGB = np.zeros(YUV.shape)
    RGB[:,:,0] = R
    RGB[:,:,1] = G
    RGB[:,:,2] = B
    return RGB


def RGB_to_YUV(RGB):
    YUV = np.zeros(RGB.shape)
    YUV[:,:,0] = (0.30*RGB[:,:,0] + 0.59*RGB[:,:,1] + 0.11*RGB[:,:,2])/255.0
    YUV[:,:,1] = (0.60*RGB[:,:,0] - 0.28*RGB[:,:,1] - 0.32*RGB[:,:,2])/255.0
    YUV[:,:,2] = (0.21*RGB[:,:,0] - 0.52*RGB[:,:,1] + 0.31*RGB[:,:,2])/255.0
    return YUV

def find_marked(blackwhite, marked):
    blackwhite = blackwhite.astype(float) / 255.0
    marked     = marked.astype(float) / 255.0
    return abs(blackwhite - marked).sum(2) > 0.01

def index_matrix(YUV):
    n    = YUV.shape[0]
    m    = YUV.shape[1]
    size = n*m
    return np.arange(size).reshape(n,m,order='F').copy()
        
def find_neighbor(Y,r,wd):
    max_num = (1+2*wd)**2
    idx_col=np.zeros(max_num,dtype=np.int64)
    window_vals = np.zeros(max_num,dtype=np.float64)
    idx = 0
    for ii in range(max(0,r[0]-wd),min(r[0]+wd+1,Y.shape[0])):
        for jj in range(max(0,r[1]-wd),min(r[1]+wd+1,Y.shape[1])):
            if (ii != r[0] or jj != r[1]):
                location_matrix   = index_matrix(Y)
                idx_col[idx]      = location_matrix[ii,jj]
                window_vals[idx]  = Y[ii,jj]
                idx               = idx +1
    return idx,idx_col[0:idx],window_vals[0:idx]    
            
def calc_variance(Y,window_vals,r):
    center = Y[r[0],r[1]].copy()                                      
    variance = np.mean((window_vals - np.mean(window_vals))**2) 
    sigma = variance * 0.6

    mgv = min(( window_vals - center )**2)            
    if (sigma < ( -mgv / np.log(0.01 ))):
        sigma = -mgv / np.log(0.01)                                     
    if (sigma < 0.000002):                                        
        sigma = 0.000002
    
    return sigma        
                                                                  
def calc_weights(Y,window_vals,sigma,r):
    center  = Y[r[0],r[1]]
    weights = np.exp( -((window_vals - center)**2) / sigma )  
    weights = weights / np.sum(weights)
    return weights

def get_colors(blackwhite,marked):
     # FIND THE LOCATION OF MARKED AREA    
    isColored  = find_marked(blackwhite,marked)
    
    # CONVERT FROM RGB TO YUV FORMAT
    blackwhite_YUV = RGB_to_YUV(blackwhite)
    marked_YUV = RGB_to_YUV(marked)
    YUV        = np.zeros(blackwhite.shape)                                                  
    YUV[:,:,0] = blackwhite_YUV[:,:,0]
    YUV[:,:,1] = marked_YUV[:,:,1]
    YUV[:,:,2] = marked_YUV[:,:,2]
    
    # BEGIN TO CONSTRUCT A SUCH THAT Ax=b                                                                                   
    n          = YUV.shape[0]                                                                
    m          = YUV.shape[1]                                                                
    size       = n*m
    
    location_matrix = index_matrix(YUV)
    
    wd         = 1                                                                     
    num_pixel  = (2*wd + 1)**2                                                  
    max_num    = size * num_pixel          
                              
    # ROW and COL OF NONZERO VALUES IN THE SPARSE MATRIX A                                                                           
    row_inds   = np.zeros(max_num, dtype=np.int64)
    col_inds   = np.zeros(max_num, dtype=np.int64)
    vals       = np.zeros(max_num)
    
    length     = 0                                                                 
    pixel_num  = 0                                                               
    
    for j in range(m):
        for i in range(n):
            if (not isColored[i,j]):
                window_vals  = np.zeros(num_pixel)                             
                
                temp_num,temp_col_inds,temp_vals = find_neighbor(YUV[:,:,0],[i,j],wd)
                length = length + temp_num
                col_inds[length - temp_num:length] = temp_col_inds
                row_inds[length - temp_num:length] = pixel_num
                window_vals[0:temp_num] = temp_vals
                
                sigma=calc_variance(YUV[:,:,0],temp_vals,[i,j])
                
                vals[length-temp_num:length] = - calc_weights(YUV[:,:,0],temp_vals,sigma,[i,j])

            row_inds[length] = pixel_num          
            col_inds[length] = location_matrix[i,j]
            vals[length] = 1
            length += 1
            pixel_num += 1
    
    # Trim to variables to the length that does not include overflow from the edges
    vals = vals[0:length]
    col_inds = col_inds[0:length]
    row_inds = row_inds[0:length]
    
    A = sparse.csr_matrix((vals, (row_inds, col_inds)), (pixel_num, size))
    # TO CONSTRUCT b, SUCH THAT Ax=b
    b = np.zeros((A.shape[0]))
    
    colorized_YUV = np.zeros(YUV.shape)                                                 
    colorized_YUV[:,:,0] = YUV[:,:,0]
    
    color_copy_for_nonzero = isColored.reshape(size,order='F').copy()                   
    colored_inds = np.nonzero(color_copy_for_nonzero)                              
    
    for channel in [1,2]:
        curIm = YUV[:,:,channel].reshape(size,order='F').copy()
        b[colored_inds] = curIm[colored_inds]
        new_vals = linalg.spsolve(A, b)                                             

        colorized_YUV[:,:,channel] = new_vals.reshape(n, m, order='F')
        
    # CONVERT FROM YUV TO RGB
    colorized_RGB = YUV_to_RGB(colorized_YUV)
    
    return colorized_RGB

    
def gray_to_RGB(blackwhite_YUV,colored_YUV):
    [row,col,channel] = blackwhite_YUV.shape
    colored_Y         = colored_YUV[:,:,0]
    if channel>0:
        blackwhite_Y  = blackwhite_YUV[:,:,0]
    else:
        blackwhite_Y  = blackwhite_YUV
    
    max_BW,min_BW           = np.max(blackwhite_Y),np.min(blackwhite_Y)
    max_color,min_color     = np.max(colored_Y),np.min(colored_Y)
    # NORMALIZATION
    colored_Y_normalized    = (255*colored_Y) /(255-(max_color - min_color))
    blackwhite_Y_normalized = (255*blackwhite_Y) /(255-(max_BW - min_BW))
    
    BW_colorized_YUV        = np.zeros(colored_YUV.shape)
    BW_colorized_YUV[:,:,0] = blackwhite_Y
    for i in range(row):
        for j in range(col):
            grey_val    = blackwhite_Y_normalized[i,j]
            diff_matrix = abs(colored_Y_normalized - grey_val)
            min_idx     = np.argwhere(diff_matrix == np.min(diff_matrix))
            if len(min_idx)>0:
                ii = min_idx[0][0]
                jj = min_idx[0][1]
            BW_colorized_YUV[i,j,1] = colored_YUV[ii,jj,1]
            BW_colorized_YUV[i,j,2] = colored_YUV[ii,jj,2]
    
    # CONVERT FROM YUV TO RGB
    BW_colorized_RGB = YUV_to_RGB(BW_colorized_YUV)
    
    return BW_colorized_RGB


def main():
    # DATA PREPARATION
    parser = argparse.ArgumentParser(description="Intelligently color black and white images")
    parser.add_argument('-i','--input',help='Specify the name of black and white image')
    parser.add_argument('-m','--mark',help='Specify the name of marked image')
    parser.add_argument('-o','--output',help='Specify the output file name')
    
    args = vars(parser.parse_args())
    print(args)
    
    blackwhite_path = args['input']
    mark_path       = args['mark']
    out_name_path   = args['output']

    bw_file_path     = os.path.join(PIC_DIR, blackwhite_path + EXTENSION)
    marked_file_path = os.path.join(PIC_DIR, mark_path + EXTENSION)
    out_file_path    = os.path.join(PIC_DIR, out_name_path + EXTENSION)
    
    blackwhite_RGB   = misc.imread(bw_file_path)
    marked_RGB       = misc.imread(marked_file_path)

    colorized_RGB    = get_colors(blackwhite_RGB,marked_RGB)

    # SHOW COLORIZED IMAGE
    plt.imshow(colorized_RGB)
    plt.show()
    #SAVE COLORIZED IMAGE
    misc.imsave(out_file_path, colorized_RGB, format='bmp')


if __name__ == '__main__':
    main()