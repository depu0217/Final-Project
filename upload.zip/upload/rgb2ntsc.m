function yuv = rgb2ntsc(RGB)

    row = size(RGB,1);
    col = size(RGB,2);
    channel = size(RGB,3);

% YUV format
%     for ii = 1:row
%         for jj = 1:col
%             R = RGB(ii,jj,1);
%             G = RGB(ii,jj,2);
%             B = RGB(ii,jj,3);
%             yuv(ii,jj,1) = 0.299 * R + 0.587*G + 0.114 *B;
%             yuv(ii,jj,2) = 0.596 * R - 0.274*G - 0.322 *B;
%             yuv(ii,jj,3) = 0.211 * R - 0.523*G + 0.312 *B;
% 
%         end
%     end

% YIQ format
    for ii = 1:row
        for jj = 1:col
            R = RGB(ii,jj,1);
            G = RGB(ii,jj,2);
            B = RGB(ii,jj,3);
            yuv(ii,jj,1) = 0.30 * R + 0.59*G + 0.11 *B;
            yuv(ii,jj,2) = 0.60 * R - 0.28*G - 0.32 *B;
            yuv(ii,jj,3) = 0.21 * R - 0.52*G + 0.31 *B;

        end
    end

end