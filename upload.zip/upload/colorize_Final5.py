import numpy as np
import matplotlib.pyplot as plt
from scipy import misc
from scipy import io
from scipy import sparse
from scipy.sparse import linalg
import colorsys
import os
import time
import sys
import argparse

PIC_DIR = 'pics'
EXTENSION = '.bmp'

os.system('cls')
os.system('reset')

def YUV2RGB(Y, U, V):                                                        # the code from colorsys.yiq_to_rgb is modified to work for arrays
    R = Y + 0.948262*U + 0.624013*V
    G = Y - 0.276066*U - 0.639810*V
    B = Y - 1.105450*U + 1.729860*V
    R[R < 0] = 0
    R[R > 1] = 1
    G[G < 0] = 0
    G[G > 1] = 1
    B[B < 0] = 0
    B[B > 1] = 1
    return (R, G, B)


def RGB2YUV(R, G, B):
    Y = 0.30*R + 0.59*G + 0.11*B
    U = 0.60*R - 0.28*G - 0.32*B
    V = 0.21*R - 0.52*G + 0.31*B
    return (Y, U, V)

def find_marked_space(original,mark):
    original = original.astype(float)/255.0
    mark = mark.astype(float)/255.0
    diff = original - mark
    return abs(diff).sum(2) > 0.01

def find_neighbor(location_matrix,i,j,wd):
    left,right = max(i - wd,0), min(i + wd,location_matrix.shape[0])
    down,up    = max(j - wd,0), min(j + wd, location_matrix.shape[1])
    return location_matrix[left:right+1,down:up+1]

def calc_variance(Y,wd):
    results = np.zeros(Y.shape,dtype = 'float32')
    for i in range(Y.shape[0]):
        for j in range(Y.shape[1]):
            vals     = find_neighbor(Y,i,j,wd)
            variance = np.mean((vals - np.mean(vals))**2)
            variance = 0.6 * variance
            center   = Y[i,j]
            mgv      = min((vals - center)**2)
            if (variance < (-mgv / np.log(0.01))):
                variance = - mgv / np.log(0.01)
            if (variance < 0.000002):
                variance = 0.000002
            results[i,j] = variance
    return results
        
def calc_weight(Y,r,neighbors,variance,mode):
    results = []
    for s in neighbors:
        results.append(np.exp(-1*np.square(Y[r] - Y[s])/(2*variance[r])))
    results = np.array(results)/np.mean(results)
    return results 
        
def calc_weights(Y,i,j,wd,mode):

    row,col = Y.shape[0:2]
    center  = Y[i,j]
    idx = 0
    num_pix = (1+2*wd)**2
    vals    = np.zeros(num_pix)
    weights = np.zeros(num_pix)
    loc_row = np.zeros(num_pix)
    loc_col = np.zeros(num_pix)

    for ii in range(max(0, i-wd), min(i+wd+1,row)):
        for jj in range(max(0, j-wd), min(j+wd+1, col)):
            if ii != i and jj != j:
                vals[idx]    = Y[ii,jj]
                loc_row[idx] = ii 
                loc_col[idx] = jj 
                idx          = idx + 1
    vals[idx]   = center
    variance    = np.mean((vals[0:idx+1] - np.mean(vals[0:idx+1]))**2)
    variance    = 0.6 * variance

    mgv = min((vals[0:idx+1] - center)**2)
    if (variance < (-mgv / np.log(0.01))):
    	variance = - mgv / np.log(0.01)
    if (variance < 0.000002):
    	variance = 0.000002
	
    if mode == 1:
        vals           = np.exp( -((vals[0:idx] - center)**2) / variance )
        weights[0:idx] = vals[0:idx] / np.sum(vals[0:idx])
    elif mode == 2:
        mu             = np.mean(vals[0:idx])
        vals           = np.ones([idx,1]) + (center - mu)*(vals[0:idx] - mu*np.ones([idx,1]))/variance
        weights[0:idx] = vals[0:idx] / np.sum(vals[0:idx])

    return loc_row[0:idx],loc_col[0:idx],weights[0:idx]

def generate_weight_matrix(Y,wd,mode):
    row,col = Y.shape[0:2]
    
    max_num = row*col*(1+2*wd)**2
    vals    = np.zeros(max_num)
    idx_row = np.zeros(max_num,dtype=np.int64)
    idx_col = np.zeros(max_num,dtype=np.int64)

    length = 0
    for i in range(row):
        for j in range(col):
            loc_row,loc_col,weights             = calc_weights(Y,i,j,wd,mode)
            window_len                          = len(loc_row)
            length                              = length + window_len
            vals[length - window_len:length]    = - weights
            idx_row[length - window_len:length] = i*col + j
            idx_col[length - window_len:length] = loc_row *col + loc_col
            
    return idx_row,idx_col,vals

def main():
    # DATA PREPARATION
#    parser = argparse.ArgumentParser(description="Intelligently crop an image along one axis")
#    parser.add_argument('-i','--input',help='Specify the name of black and white image')
#    parser.add_argument('-m','--mark',help='Specify the name of marked image')
#    parser.add_argument('-o','--output',help='Specify the output file name')
    
#    args = vars(parser.parse_args())
#    print(args)
#    
#    blackwhite_path = args['input']
#    mark_path     = args['mark']
#    out_name_path = args['output']
    
    blackwhite_path = 'example'
    mark_path = 'example_marked'
    out_name_path = 'test'
    
    blackwhite_path  = os.path.join(PIC_DIR,blackwhite_path + EXTENSION)
    mark_path        = os.path.join(PIC_DIR,mark_path + EXTENSION)
    out_name_path    = os.path.join(PIC_DIR,out_name_path + EXTENSION)
    
    blackwhite_RGB   = misc.imread(blackwhite_path)
    marked_RGB       = misc.imread(mark_path)
    
    wd       = 1
    row,col  = blackwhite_RGB.shape[0:2]
    img_size = row*col
    
    # FIND THE LOCATION OF MARKED AREA
    colored          = find_marked_space(blackwhite_RGB,marked_RGB)
    colored_shaped   = colored.reshape(row*col,order = 'F').copy()
    colored_location = np.nonzero(colored_shaped) 
    
    # CONVERT FROM RGB TO YUV FORMAT
    blackwhite_RGB   = blackwhite_RGB.astype(float)/255.0
    marked_RGB       = marked_RGB.astype(float)/255.0
    (Y,_,_)          = RGB2YUV(blackwhite_RGB[:,:,0],blackwhite_RGB[:,:,1],blackwhite_RGB[:,:,2])    
    (_,U,V)          = RGB2YUV(marked_RGB[:,:,0],marked_RGB[:,:,1],marked_RGB[:,:,2])
    

    # GENERATE WEIGHT MATRIX A
    mode = 1
    idx_row,idx_col,vals = generate_weight_matrix(Y,wd,mode)
    A = sparse.csr_matrix((vals, (idx_row, idx_col)), (img_size, img_size))
        
    # GET EXACT COLOR
    b = np.zeros((A.shape[0]))
    
    output_YUV = np.zeros([row,col,3])
    output_YUV[:,:,0] = Y
    
    U_channel = U.reshape(row*col,order='F').copy()
    b[colored_location] = U_channel[colored_location]
    output_shaped = linalg.spsolve(A,b)
    output_YUV[:,:,1] = output_shaped.reshape(row,col,order='F')
    
    V_channel = V.reshape(row*col,order='F').copy()
    b[colored_location] = V_channel[colored_location]
    output_shaped = linalg.spsolve(A,b)
    output_YUV[:,:,2] = output_shaped.reshape(row,col,order='F')
    
    # CONVERT FROM YUV TO RGB
    R,G,B = YUV2RGB(output_YUV[:,:,0],output_YUV[:,:,1],output_YUV[:,:,2])
    output_RGB = np.zeros(output_YUV.shape)
    output_RGB[:,:,0] = np.uint8(R*255)
    output_RGB[:,:,1] = np.uint8(G*255)
    output_RGB[:,:,2] = np.uint8(B*255)
    
    plt.imshow(output_RGB)
    plt.show()
    
if __name__ == '__main__':
    main()
    
